package p1;

public class MatriculaEscuela extends Matricula {

    @Override
    public void establecerTarifa() {
        // tarifa = costo libros + costo deportes + costo folletos + costo uniformes
        tarifa = 50.2 + 40.2 + 140.2 + 200.4;
    }

    @Override
    public String obtenerTipo() {
        return "MatriculaEscuela";
    }
}
