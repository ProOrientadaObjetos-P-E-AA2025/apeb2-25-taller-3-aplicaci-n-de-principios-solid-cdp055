package p1;

public abstract class Matricula {
    protected double tarifa;

    public abstract void establecerTarifa();
    public abstract String obtenerTipo();

    public double obtenerTarifa() {
        return tarifa;
    }

    @Override
    public String toString() {
        return String.format("%s - Tarifa: %.2f", obtenerTipo(), tarifa);
    }
}
