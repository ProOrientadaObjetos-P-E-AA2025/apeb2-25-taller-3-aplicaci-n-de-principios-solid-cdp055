package p3;

import java.util.ArrayList;
import p1.*;
import p2.TipoMatricula;

public class Principal {
    public static void main(String[] args) {
        // Crear lista de matrículas
        ArrayList<Matricula> lista = new ArrayList<>();

        Matricula m1 = new MatriculaCampamento();
        m1.establecerTarifa();  // MUY IMPORTANTE
        lista.add(m1);

        Matricula m2 = new MatriculaColegio();
        m2.establecerTarifa();
        lista.add(m2);

        Matricula m3 = new MatriculaEscuela();
        m3.establecerTarifa();
        lista.add(m3);

        Matricula m4 = new MatriculaJardin();
        m4.establecerTarifa();
        lista.add(m4);

        Matricula m5 = new MatriculaMaternal();
        m5.establecerTarifa();
        lista.add(m5);

        Matricula m6 = new MatriculaMaternal();
        m6.establecerTarifa();
        lista.add(m6);

        // Usar clase TipoMatricula
        TipoMatricula tipo = new TipoMatricula();
        tipo.establecerMatriculas(lista);
        tipo.establecerPromedioTarifas();

        System.out.println(tipo);
    }
}
