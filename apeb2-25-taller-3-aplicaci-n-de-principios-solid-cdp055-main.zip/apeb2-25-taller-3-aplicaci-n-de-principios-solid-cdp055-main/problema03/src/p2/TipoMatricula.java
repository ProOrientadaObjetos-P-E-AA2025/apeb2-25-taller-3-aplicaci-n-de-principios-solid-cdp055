package p2;

import java.util.ArrayList;
import p1.Matricula;

public class TipoMatricula {
    private ArrayList<Matricula> matriculas;
    private double promedioMatriculas;

    public TipoMatricula() {
        matriculas = new ArrayList<>();
    }

    public void establecerMatriculas(ArrayList<Matricula> m) {
        matriculas = m;
    }

    public void establecerPromedioTarifas() {
        if (matriculas == null || matriculas.isEmpty()) {
            promedioMatriculas = 0;
            return;
        }
        double suma = 0;
        for (Matricula m : matriculas) {
            suma += m.obtenerTarifa();
        }
        promedioMatriculas = suma / matriculas.size();
    }

    public ArrayList<Matricula> obtenerMatriculas() {
        return matriculas;
    }

    public double obtenerPromedioTarifas() {
        return promedioMatriculas;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("LISTADO DE MATRÍCULAS:\n");
        for (Matricula m : matriculas) {
            sb.append(m.obtenerTipo()).append(" - ").append(m).append("\n");
        }
        sb.append(String.format("Promedio Tarifa: %.2f\n", obtenerPromedioTarifas()));
        return sb.toString();
    }
}
