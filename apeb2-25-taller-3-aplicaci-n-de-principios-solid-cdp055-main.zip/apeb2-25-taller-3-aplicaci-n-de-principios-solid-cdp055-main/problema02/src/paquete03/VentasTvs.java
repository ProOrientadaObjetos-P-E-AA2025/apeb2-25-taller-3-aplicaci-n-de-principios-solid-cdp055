package paquete03;

import java.util.ArrayList;
import paquete01.Televisor;

public class VentasTvs {
    private double precioTotal;
    private ArrayList<Televisor> televisores;
    private String marcasVendidas;
    private Televisor televisorMasCaro;

    public void establecerTelevisores(ArrayList<Televisor> t) {
        televisores = t;
    }

    public void establecerPrecioTotal() {
        double suma = 0;
        for (Televisor t : televisores) {
            suma += t.obtenerPrecio();
        }
        precioTotal = suma;
    }

    public void establecerMarcasVendidas() {
        StringBuilder sb = new StringBuilder();
        for (Televisor t : televisores) {
            sb.append(t.obtenerMarca()).append("\n");
        }
        marcasVendidas = sb.toString();
    }

    public void establecerTelevisorMasCaro() {
        double mayor = -1;
        Televisor caro = null;
        for (Televisor t : televisores) {
            if (t.obtenerPrecio() > mayor) {
                mayor = t.obtenerPrecio();
                caro = t;
            }
        }
        televisorMasCaro = caro;
    }

    public double obtenerPrecioTotal() {
        return precioTotal;
    }

    public String obtenerMarcasVendidas() {
        return marcasVendidas;
    }

    public Televisor obtenerTelevisorMasCaro() {
        return televisorMasCaro;
    }
}
