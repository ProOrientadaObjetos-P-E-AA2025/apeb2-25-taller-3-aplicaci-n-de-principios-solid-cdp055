package paquete02;

import java.util.ArrayList;
import paquete01.Televisor;
import paquete03.VentasTvs;

public class Principal {

    public static void main(String[] args) {
        // Crear televisores
        Televisor t1 = new Televisor();
        t1.establecerMarca("LG-14 pulgadas");
        t1.establecerPrecio(300.2);

        Televisor t2 = new Televisor();
        t2.establecerMarca("SAMSUNG-21 pulgadas");
        t2.establecerPrecio(1300.2);

        Televisor t3 = new Televisor();
        t3.establecerMarca("RIVIERA-29 pulgadas");
        t3.establecerPrecio(2300.5);

        ArrayList<Televisor> tvs = new ArrayList<>();
        tvs.add(t1);
        tvs.add(t2);
        tvs.add(t3);

        // Crear objeto de ventas
        VentasTvs ventas = new VentasTvs();
        ventas.establecerTelevisores(tvs);
        ventas.establecerPrecioTotal();
        ventas.establecerMarcasVendidas();
        ventas.establecerTelevisorMasCaro();

        // Imprimir reporte
        System.out.println("------- REPORTE DE VENTAS -------");
        System.out.printf("Total precio TVs: %.2f\n", ventas.obtenerPrecioTotal());
        System.out.println("Marcas Vendidas:");
        System.out.println(ventas.obtenerMarcasVendidas());
        System.out.println("Televisor más caro:");
        System.out.println(ventas.obtenerTelevisorMasCaro());
    }
}
