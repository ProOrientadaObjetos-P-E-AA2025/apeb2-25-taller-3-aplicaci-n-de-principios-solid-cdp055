package paquete004;

public class PagoPredial extends Pago {
    private double valorPropiedad;
    private double porcentajeImpuesto;

    public PagoPredial(double valorPropiedad, double porcentajeImpuesto) {
        this.valorPropiedad = valorPropiedad;
        this.porcentajeImpuesto = porcentajeImpuesto;
    }

    @Override
    public void calcularPago() {
        valorPago = valorPropiedad - ((valorPropiedad * porcentajeImpuesto) / 100);
    }

    @Override
    public String obtenerDetallesPago() {
        return String.format("Pago Predial: $%.2f", valorPago);
    }
}
