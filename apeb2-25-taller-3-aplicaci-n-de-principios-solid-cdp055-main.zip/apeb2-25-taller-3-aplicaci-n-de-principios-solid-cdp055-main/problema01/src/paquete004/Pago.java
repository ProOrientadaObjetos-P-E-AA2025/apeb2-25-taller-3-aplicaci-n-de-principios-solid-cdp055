package paquete004;

public abstract class Pago {
    protected double valorPago;

    public abstract void calcularPago();

    public double obtenerValorPago() {
        return valorPago;
    }

    public abstract String obtenerDetallesPago();
}
