package paquete004;

public class PagoLuzElectrica extends Pago {
    private double tarifaBase;
    private double kilovatiosConsumidos;
    private double costoKilovatio;
    private String ciudad;

    public PagoLuzElectrica(double tarifaBase, double kilovatiosConsumidos, double costoKilovatio, String ciudad) {
        this.tarifaBase = tarifaBase;
        this.kilovatiosConsumidos = kilovatiosConsumidos;
        this.costoKilovatio = costoKilovatio;
        this.ciudad = ciudad;
    }

    @Override
    public void calcularPago() {
        if (ciudad.equalsIgnoreCase("Loja")) {
            valorPago = tarifaBase + (kilovatiosConsumidos * costoKilovatio / 2);
        } else {
            valorPago = tarifaBase + (kilovatiosConsumidos * costoKilovatio);
        }
    }

    @Override
    public String obtenerDetallesPago() {
        return String.format("Pago Luz Eléctrica (%s): $%.2f", ciudad, valorPago);
    }
}
