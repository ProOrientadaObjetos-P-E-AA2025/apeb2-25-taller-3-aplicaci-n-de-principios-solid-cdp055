package paquete004;

public class PagoTelefonoConvencional extends Pago {
    private double tarifaBase;
    private double minutosConsumidos;
    private double costoMinuto;

    public PagoTelefonoConvencional(double tarifaBase, double minutosConsumidos, double costoMinuto) {
        this.tarifaBase = tarifaBase;
        this.minutosConsumidos = minutosConsumidos;
        this.costoMinuto = costoMinuto;
    }

    @Override
    public void calcularPago() {
        valorPago = tarifaBase + (minutosConsumidos * costoMinuto);
    }

    @Override
    public String obtenerDetallesPago() {
        return String.format("Pago Teléfono Convencional: $%.2f", valorPago);
    }
}
