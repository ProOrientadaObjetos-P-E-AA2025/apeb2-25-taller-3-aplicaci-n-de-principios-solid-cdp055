/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package paquete006;

/**
 *
 * @author reroes
 */
public class DatosLuz {
    /*
    
    */
    public static double[][] datosLoja(){
        double[][] informacion = {
            {12.0, 100.2, 0.2},
            {12.1, 50.2, 0.4},
            {12.2, 100.3, 0.1},
        };
        return informacion;
    }
    
    public static double[][] datosGeneral(){
        double[][] informacion = {
            {11.20, 80.2, 0.3},
            {12.40, 70.2, 0.3},
            {13.60, 90.3, 0.3},
        };
        return informacion;
    }
}
