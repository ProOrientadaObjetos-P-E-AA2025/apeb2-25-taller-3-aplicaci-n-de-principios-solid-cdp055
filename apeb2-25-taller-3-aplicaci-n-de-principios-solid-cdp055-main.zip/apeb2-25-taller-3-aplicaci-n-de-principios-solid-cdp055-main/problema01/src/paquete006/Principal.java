package paquete006;

import paquete003.BilleteraPagos;
import paquete001.Persona;
import paquete002.Ciudad;
import paquete004.PagoAguaPotable;
import paquete004.PagoLuzElectrica;
import paquete004.PagoPredial;
import paquete004.PagoTelefonoConvencional;

public class Principal {
    public static void main(String[] args) {
        // Crear Persona y Ciudad
        Ciudad ciudad = new Ciudad();
        ciudad.setNombreCiudad("Loja");

        Persona persona = new Persona("David", "Piedra", 25, "1234567890", ciudad);


        // Crear Billetera
        BilleteraPagos billetera = new BilleteraPagos(persona, "Julio 2025");

        // Cargar datos Agua Potable (casas y comerciales)
        double[][] datosCasasAgua = DatosAgua.datosCasas();
        for (double[] datos : datosCasasAgua) {
            double tarifaFija = datos[0];
            double consumo = datos[1];
            double costoConsumo = datos[2];
            PagoAguaPotable pago = new PagoAguaPotable("casa", tarifaFija, consumo, costoConsumo);
            billetera.agregarPago(pago);
        }

        double[][] datosComercialesAgua = DatosAgua.datosComerciales();
        for (double[] datos : datosComercialesAgua) {
            double tarifaFija = datos[0];
            double consumo = datos[1];
            double costoConsumo = datos[2];
            PagoAguaPotable pago = new PagoAguaPotable("comercial", tarifaFija, consumo, costoConsumo);
            billetera.agregarPago(pago);
        }

        // Cargar datos Luz Eléctrica (Loja y General)
        double[][] datosLojaLuz = DatosLuz.datosLoja();
        for (double[] datos : datosLojaLuz) {
            double tarifaBase = datos[0];
            double kilovatios = datos[1];
            double costoKw = datos[2];
            PagoLuzElectrica pago = new PagoLuzElectrica(tarifaBase, kilovatios, costoKw, "Loja");
            billetera.agregarPago(pago);
        }

        double[][] datosGeneralLuz = DatosLuz.datosGeneral();
        for (double[] datos : datosGeneralLuz) {
            double tarifaBase = datos[0];
            double kilovatios = datos[1];
            double costoKw = datos[2];
            PagoLuzElectrica pago = new PagoLuzElectrica(tarifaBase, kilovatios, costoKw, "General");
            billetera.agregarPago(pago);
        }

        // Cargar datos Propiedades
        double[][] datosPropiedades = DatosPropiedades.datos();
        for (double[] datos : datosPropiedades) {
            double valorPropiedad = datos[0];
            double porcentaje = datos[1];
            PagoPredial pago = new PagoPredial(valorPropiedad, porcentaje);
            billetera.agregarPago(pago);
        }

        // Cargar datos Teléfono
        double[][] datosTelefonos = DatosTelefono.datos();
        for (double[] datos : datosTelefonos) {
            double tarifa = datos[0];
            double minutos = datos[1];
            double costoMinuto = datos[2];
            PagoTelefonoConvencional pago = new PagoTelefonoConvencional(tarifa, minutos, costoMinuto);
            billetera.agregarPago(pago);
        }

        // Mostrar reporte final
        System.out.println(billetera);
    }
}
