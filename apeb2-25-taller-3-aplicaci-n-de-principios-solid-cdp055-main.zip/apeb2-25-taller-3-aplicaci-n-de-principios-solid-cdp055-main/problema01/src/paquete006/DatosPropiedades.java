/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package paquete006;

/**
 *
 * @author reroes
 */
public class DatosPropiedades {
    /*
    
    */
    public static double[][] datos(){
        double[][] informacion = {
            {120000, 10},
            {40000, 20},
            {100000, 10},
            {50000, 20},
        };
        return informacion;
    }
    
    
}
