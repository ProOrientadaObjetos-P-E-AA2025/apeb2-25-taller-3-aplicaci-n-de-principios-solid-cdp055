/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package paquete006;

/**
 *
 * @author reroes
 */
public class DatosTelefono {
    /*
    
    */
    public static double[][] datos(){
        double[][] informacion = {
            {6.0, 200.2, 0.2},
            {6.1, 250.2, 0.4},
            {6.2, 300.3, 0.1},
        };
        return informacion;
    }
    
    
}
