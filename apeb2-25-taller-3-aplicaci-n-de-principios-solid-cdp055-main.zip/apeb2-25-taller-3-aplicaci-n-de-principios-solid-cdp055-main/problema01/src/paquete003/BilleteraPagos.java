package paquete003;

import paquete001.Persona;
import paquete004.Pago;
import java.util.ArrayList;

public class BilleteraPagos {
    private Persona persona;
    private String mes;
    private ArrayList<Pago> listaPagos;

    public BilleteraPagos(Persona persona, String mes) {
        this.persona = persona;
        this.mes = mes;
        this.listaPagos = new ArrayList<>();
    }

    public void agregarPago(Pago pago) {
        pago.calcularPago();
        listaPagos.add(pago);
    }

    public double obtenerTotalPagos() {
        double total = 0;
        for (Pago p : listaPagos) {
            total += p.obtenerValorPago();
        }
        return total;
    }

    @Override
    public String toString() {
        StringBuilder reporte = new StringBuilder();
        reporte.append("----- REPORTE BILLETERA DE PAGOS -----\n");
        reporte.append("Mes: ").append(mes).append("\n");
        if (persona != null) {
            reporte.append("Persona: ").append(persona.toString()).append("\n\n");
        }
        for (Pago p : listaPagos) {
            reporte.append(p.obtenerDetallesPago()).append("\n");
        }
        reporte.append("\nTOTAL PAGADO: $").append(String.format("%.2f", obtenerTotalPagos()));
        return reporte.toString();
    }
}
