package paquete005;

import paquete003.BilleteraPagos;
import paquete001.Persona;
import paquete002.Ciudad;
import paquete004.PagoAguaPotable;
import paquete004.PagoLuzElectrica;
import paquete004.PagoPredial;
import paquete004.PagoTelefonoConvencional;

public class Principal {
    public static void main(String[] args) {
        // Crear objeto Ciudad
        Ciudad ciudad = new Ciudad();
        ciudad.setNombreCiudad("Loja");  // CORREGIDO

        // Crear persona con constructor completo
        Persona persona = new Persona("David", "Piedra", 25, "1234567890", ciudad);

        // Crear billetera con persona y mes
        BilleteraPagos billetera = new BilleteraPagos(persona, "Julio 2025");

        // Crear pagos con los datos correspondientes
        PagoAguaPotable aguaCasa = new PagoAguaPotable("casa", 2.20, 100.2, 0.2);
        PagoAguaPotable aguaComercio = new PagoAguaPotable("comercial", 2.20, 100.2, 0.2);

        PagoLuzElectrica luzCasa = new PagoLuzElectrica(10.20, 80, 0.5, "Loja");
        PagoLuzElectrica luzComercio = new PagoLuzElectrica(10.20, 100, 0.5, "Quito");

        PagoPredial casa1 = new PagoPredial(56000, 10);
        PagoPredial casa2 = new PagoPredial(40000, 8);

        PagoTelefonoConvencional telefonoCasa = new PagoTelefonoConvencional(6.20, 100, 0.2);
        PagoTelefonoConvencional telefonoFinca = new PagoTelefonoConvencional(6.20, 200, 0.15);

        // Agregar pagos a la billetera
        billetera.agregarPago(aguaCasa);
        billetera.agregarPago(aguaComercio);
        billetera.agregarPago(luzCasa);
        billetera.agregarPago(luzComercio);
        billetera.agregarPago(casa1);
        billetera.agregarPago(casa2);
        billetera.agregarPago(telefonoCasa);
        billetera.agregarPago(telefonoFinca);

        // Mostrar reporte
        System.out.println(billetera);
    }
}
